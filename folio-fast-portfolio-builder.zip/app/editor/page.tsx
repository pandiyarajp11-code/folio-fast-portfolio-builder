import type { Metadata } from 'next'
import { EditorClient } from '@/components/editor/editor-client'
import { LiquidBackground } from '@/components/liquid-background'
import { SiteHeader } from '@/components/site-header'

export const metadata: Metadata = {
  title: 'Editor — FolioFast',
  description: 'Edit your extracted resume data and preview your portfolio live.',
}

export default function EditorPage() {
  return (
    <div className="flex min-h-dvh flex-col">
      <LiquidBackground />
      <SiteHeader />
      <main className="flex flex-1 flex-col">
        <EditorClient />
      </main>
    </div>
  )
}
