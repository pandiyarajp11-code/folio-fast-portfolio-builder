import type { Metadata } from 'next'
import { PublicPortfolio } from '@/components/public/public-portfolio'

type Props = { params: Promise<{ username: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { username } = await params
  return {
    title: `@${username} — Portfolio | FolioFast`,
    description: `View ${username}'s portfolio, built with FolioFast.`,
  }
}

export default async function PublicPortfolioPage({ params }: Props) {
  const { username } = await params
  return <PublicPortfolio username={decodeURIComponent(username).toLowerCase()} />
}
