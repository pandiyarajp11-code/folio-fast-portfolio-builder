import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { btn } from '@/components/glass'
import { Features } from '@/components/landing/features'
import { Hero } from '@/components/landing/hero'
import { ThemePreviews } from '@/components/landing/theme-previews'
import { LiquidBackground } from '@/components/liquid-background'
import { SiteHeader } from '@/components/site-header'

export default function HomePage() {
  return (
    <>
      <LiquidBackground />
      <SiteHeader />
      <main>
        <Hero />
        <Features />
        <ThemePreviews />
        <section className="mx-auto max-w-4xl px-4 py-24 text-center">
          <h2 className="text-balance font-display text-4xl font-semibold tracking-tight md:text-5xl">
            Your next opportunity starts with <span className="text-liquid">one link.</span>
          </h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/#upload" className={btn('liquid')}>
              Upload resume
              <ArrowRight aria-hidden="true" />
            </Link>
            <Link href="/dashboard" className={btn('ghost')}>
              View my portfolios
            </Link>
          </div>
        </section>
      </main>
      <footer className="border-t border-white/5 py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} FolioFast. Crafted for builders.
      </footer>
    </>
  )
}
