import type { Metadata } from 'next'
import { DashboardClient } from '@/components/dashboard/dashboard-client'
import { LiquidBackground } from '@/components/liquid-background'
import { SiteHeader } from '@/components/site-header'

export const metadata: Metadata = {
  title: 'Dashboard — FolioFast',
  description: 'Manage the portfolios you have published with FolioFast.',
}

export default function DashboardPage() {
  return (
    <>
      <LiquidBackground />
      <SiteHeader />
      <main>
        <DashboardClient />
      </main>
    </>
  )
}
