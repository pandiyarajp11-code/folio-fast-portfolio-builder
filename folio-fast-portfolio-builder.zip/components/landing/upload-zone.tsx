'use client'

import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { AnimatePresence, motion } from 'framer-motion'
import { AlertCircle, FileText, Loader2, UploadCloud, Wand2 } from 'lucide-react'
import { btn } from '@/components/glass'
import { SAMPLE_RESUME_TEXT, extractTextFromPdf, parseResumeText } from '@/lib/parse-resume'
import { getPortfolios, saveDraft } from '@/lib/storage'
import { cn } from '@/lib/utils'

type Status = { kind: 'idle' } | { kind: 'working'; label: string; file?: string } | { kind: 'error'; message: string }

const MAX_SIZE = 10 * 1024 * 1024

export function UploadZone() {
  const router = useRouter()
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)
  const [status, setStatus] = useState<Status>({ kind: 'idle' })

  const finish = (text: string) => {
    const data = parseResumeText(text, Object.keys(getPortfolios()))
    saveDraft(data)
    setStatus({ kind: 'working', label: 'Building your portfolio…' })
    router.push('/editor')
  }

  const handleFile = async (file: File | undefined) => {
    if (!file) return
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      setStatus({ kind: 'error', message: 'Please upload a PDF file.' })
      return
    }
    if (file.size > MAX_SIZE) {
      setStatus({ kind: 'error', message: 'That file is over 10MB. Try a smaller PDF.' })
      return
    }
    try {
      setStatus({ kind: 'working', label: 'Reading your resume…', file: file.name })
      const text = await extractTextFromPdf(file)
      if (text.trim().length < 20) {
        setStatus({ kind: 'error', message: "We couldn't find text in this PDF. Scanned images aren't supported yet." })
        return
      }
      setStatus({ kind: 'working', label: 'Extracting skills & projects…', file: file.name })
      finish(text)
    } catch (err) {
      console.error('[foliofast] PDF parse failed', err)
      setStatus({ kind: 'error', message: 'Something went wrong reading that PDF. Please try another file.' })
    }
  }

  const working = status.kind === 'working'

  return (
    <div className="w-full">
      <motion.div
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragging(false)
          handleFile(e.dataTransfer.files?.[0])
        }}
        animate={{ scale: dragging ? 1.02 : 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className={cn(
          'glass group relative overflow-hidden rounded-3xl p-2 transition-colors',
          dragging && 'border-liquid-cyan/60',
        )}
      >
        <div className="pointer-events-none absolute -inset-px rounded-3xl bg-liquid opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-20" />
        <button
          type="button"
          disabled={working}
          onClick={() => inputRef.current?.click()}
          className="relative flex w-full flex-col items-center gap-4 rounded-2xl border border-dashed border-white/15 px-6 py-10 text-center transition-colors hover:border-white/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring md:py-12"
        >
          <AnimatePresence mode="wait">
            {working ? (
              <motion.div key="working" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="flex flex-col items-center gap-3">
                <span className="grid size-14 place-items-center rounded-2xl bg-liquid text-background">
                  <Loader2 className="size-6 animate-spin" aria-hidden="true" />
                </span>
                <p className="font-display text-lg font-medium" aria-live="polite">{status.label}</p>
                {status.file && (
                  <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <FileText className="size-4" aria-hidden="true" />
                    {status.file}
                  </p>
                )}
              </motion.div>
            ) : (
              <motion.div key="idle" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="flex flex-col items-center gap-3">
                <motion.span
                  animate={{ y: dragging ? -6 : [0, -4, 0] }}
                  transition={dragging ? { duration: 0.2 } : { duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                  className="grid size-14 place-items-center rounded-2xl bg-liquid text-background shadow-[0_0_40px_-8px_var(--liquid-violet)]"
                >
                  <UploadCloud className="size-6" aria-hidden="true" />
                </motion.span>
                <p className="font-display text-xl font-semibold">{dragging ? 'Drop it like it’s hot' : 'Upload your PDF resume'}</p>
                <p className="text-sm text-muted-foreground">Drag & drop or click to browse · PDF up to 10MB · Parsed privately in your browser</p>
              </motion.div>
            )}
          </AnimatePresence>
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf,.pdf"
          className="sr-only"
          tabIndex={-1}
          aria-label="Upload PDF resume"
          onChange={(e) => {
            handleFile(e.target.files?.[0])
            e.target.value = ''
          }}
        />
      </motion.div>

      <div className="mt-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <AnimatePresence>
          {status.kind === 'error' && (
            <motion.p
              role="alert"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2 text-sm text-destructive"
            >
              <AlertCircle className="size-4" aria-hidden="true" />
              {status.message}
            </motion.p>
          )}
        </AnimatePresence>
        <button type="button" disabled={working} onClick={() => finish(SAMPLE_RESUME_TEXT)} className={btn('subtle')}>
          <Wand2 aria-hidden="true" />
          No resume handy? Try a sample
        </button>
      </div>
    </div>
  )
}
