'use client'

import { motion } from 'framer-motion'
import { PortfolioView, THEMES } from '@/components/portfolio/portfolio-view'
import { SAMPLE_RESUME_TEXT, parseResumeText } from '@/lib/parse-resume'

const SAMPLE = { ...parseResumeText(SAMPLE_RESUME_TEXT), username: 'pandiyaraj11' }

export function ThemePreviews() {
  return (
    <section id="themes" className="mx-auto max-w-6xl scroll-mt-24 px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
        className="mx-auto max-w-2xl text-center"
      >
        <p className="text-sm font-medium text-liquid-pink">Themes</p>
        <h2 className="mt-3 text-balance font-display text-4xl font-semibold tracking-tight md:text-5xl">Two looks. Both unforgettable.</h2>
        <p className="mt-4 text-muted-foreground">Visitors can flip between themes with the floating toggle on your public page.</p>
      </motion.div>

      <div className="mt-14 grid gap-6 lg:grid-cols-2">
        {THEMES.map((theme, i) => (
          <motion.figure
            key={theme.id}
            initial={{ opacity: 0, y: 30, scale: 0.97 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
            className="glass group overflow-hidden rounded-3xl p-2"
          >
            <div className="flex items-center gap-1.5 px-3 py-2" aria-hidden="true">
              <span className="size-2.5 rounded-full bg-white/15" />
              <span className="size-2.5 rounded-full bg-white/15" />
              <span className="size-2.5 rounded-full bg-white/15" />
              <span className="ml-3 truncate rounded-md bg-white/5 px-2 py-0.5 font-mono text-[11px] text-muted-foreground">
                foliofast.app/u/{SAMPLE.username}
              </span>
            </div>
            <div className="relative h-80 overflow-hidden rounded-2xl md:h-96" inert>
              <div className="absolute left-0 top-0 w-[200%] origin-top-left scale-50 transition-transform duration-[2500ms] ease-in-out group-hover:-translate-y-[20%]">
                <PortfolioView data={SAMPLE} theme={theme.id} embedded />
              </div>
            </div>
            <figcaption className="flex items-center justify-between px-3 py-4">
              <div>
                <p className="font-display font-semibold">{theme.name}</p>
                <p className="text-sm text-muted-foreground">{theme.description}</p>
              </div>
              <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-muted-foreground">Theme {i + 1}</span>
            </figcaption>
          </motion.figure>
        ))}
      </div>
    </section>
  )
}
