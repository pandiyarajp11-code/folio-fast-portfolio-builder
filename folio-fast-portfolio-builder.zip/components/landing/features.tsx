'use client'

import { motion } from 'framer-motion'
import { Braces, Download, Globe, Palette, ScanText, ShieldCheck } from 'lucide-react'
import { GlassCard } from '@/components/glass'

const FEATURES = [
  { icon: ScanText, title: 'Smart extraction', body: 'Name, bio, skills, projects, experience, education and contact pulled out automatically.' },
  { icon: Braces, title: 'Live JSON editor', body: 'Tweak anything in structured JSON and watch your site update in real time.' },
  { icon: Palette, title: 'Two premium themes', body: 'Switch between Minimal Liquid and Dark Aurora with a single tap.' },
  { icon: Globe, title: 'Instant public link', body: 'Publish to a clean /u/username URL generated from your name.' },
  { icon: Download, title: 'Share & export', body: 'Native share sheet, copy link, or download your portfolio as a crisp PNG.' },
  { icon: ShieldCheck, title: 'Private by design', body: 'Your PDF never leaves your device. Parsing happens entirely in the browser.' },
]

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl scroll-mt-24 px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
        className="mx-auto max-w-2xl text-center"
      >
        <p className="text-sm font-medium text-liquid-cyan">Features</p>
        <h2 className="mt-3 text-balance font-display text-4xl font-semibold tracking-tight md:text-5xl">Everything you need. Nothing you don’t.</h2>
      </motion.div>
      <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.6, delay: (i % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
            whileHover={{ y: -4 }}
          >
            <GlassCard className="group h-full p-6 transition-colors hover:bg-white/[0.07]">
              <span className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/5 text-liquid-cyan transition-colors group-hover:text-liquid-pink">
                <f.icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className="mt-5 font-display text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
            </GlassCard>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
