'use client'

import { motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import { UploadZone } from './upload-zone'

const ease = [0.22, 1, 0.36, 1] as const

const STEPS = ['Upload PDF', 'Edit details', 'Publish link']

export function Hero() {
  return (
    <section id="upload" className="relative mx-auto scroll-mt-24 flex max-w-4xl flex-col items-center px-4 pb-20 pt-16 text-center md:pt-24">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease }}
        className="glass inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs text-muted-foreground"
      >
        <Sparkles className="size-3.5 text-liquid-cyan" aria-hidden="true" />
        Free · No signup · Private in-browser parsing
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 24, filter: 'blur(10px)' }}
        animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
        transition={{ duration: 0.9, ease, delay: 0.1 }}
        className="mt-6 text-balance font-display text-5xl font-semibold leading-[1.02] tracking-tight md:text-7xl"
      >
        Resume to Portfolio <span className="text-liquid">in 10 seconds</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease, delay: 0.25 }}
        className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground"
      >
        Drop your PDF resume. FolioFast extracts your story and turns it into a stunning portfolio website with a link you can share anywhere.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.9, ease, delay: 0.4 }}
        className="mt-10 w-full max-w-2xl"
      >
        <UploadZone />
      </motion.div>

      <motion.ol
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.8 }}
        className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-muted-foreground"
      >
        {STEPS.map((step, i) => (
          <li key={step} className="flex items-center gap-2">
            <span className="grid size-6 place-items-center rounded-full border border-white/15 font-display text-xs text-foreground">{i + 1}</span>
            {step}
          </li>
        ))}
      </motion.ol>
    </section>
  )
}
