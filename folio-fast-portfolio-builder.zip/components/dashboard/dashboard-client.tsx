'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, Copy, ExternalLink, Loader2, PencilLine, Plus, Trash2 } from 'lucide-react'
import { GlassCard, btn } from '@/components/glass'
import { THEMES } from '@/components/portfolio/portfolio-view'
import { initials } from '@/lib/portfolio-utils'
import { deletePortfolio, saveDraft, usePortfolios } from '@/lib/storage'
import type { StoredPortfolio } from '@/lib/types'
import { cn } from '@/lib/utils'

const dateFmt = new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' })

function PortfolioCard({ portfolio, index }: { portfolio: StoredPortfolio; index: number }) {
  const router = useRouter()
  const [copied, setCopied] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const path = `/u/${portfolio.username}`
  const themeName = THEMES.find((t) => t.id === portfolio.theme)?.name

  const copy = async () => {
    await navigator.clipboard.writeText(`${window.location.origin}${path}`).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <motion.li
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.5, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
    >
      <GlassCard className="group flex h-full flex-col p-5 transition-colors hover:bg-white/[0.07]">
        <div className="flex items-start gap-4">
          <span
            className={cn(
              'grid size-12 shrink-0 place-items-center rounded-xl font-display font-semibold',
              portfolio.theme === 'aurora' ? 'bg-gradient-to-br from-[oklch(0.8_0.17_170)] to-[oklch(0.65_0.27_300)] text-background' : 'bg-white text-slate-800',
            )}
          >
            {initials(portfolio.name)}
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="truncate font-display text-lg font-semibold">{portfolio.name || 'Untitled'}</h2>
            <p className="truncate text-sm text-muted-foreground">{portfolio.title}</p>
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between gap-2 rounded-xl bg-white/5 px-3 py-2">
          <span className="truncate font-mono text-xs text-muted-foreground">{path}</span>
          <button type="button" onClick={copy} aria-label="Copy portfolio link" className="text-muted-foreground transition-colors hover:text-foreground">
            {copied ? <Check className="size-4 text-emerald-300" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
          </button>
        </div>
        <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
          <span className="rounded-full border border-white/10 px-2 py-0.5">{themeName}</span>
          <span>Updated {dateFmt.format(portfolio.updatedAt)}</span>
        </div>
        <div className="mt-5 flex flex-1 items-end gap-2">
          <Link href={path} className={btn('primary', 'h-9 flex-1 px-3')}>
            <ExternalLink aria-hidden="true" />
            View
          </Link>
          <button
            type="button"
            onClick={() => {
              saveDraft(portfolio)
              router.push('/editor')
            }}
            className={btn('ghost', 'h-9 px-3')}
          >
            <PencilLine aria-hidden="true" />
            Edit
          </button>
          <button
            type="button"
            onClick={() => (confirming ? deletePortfolio(portfolio.username) : setConfirming(true))}
            onBlur={() => setConfirming(false)}
            aria-label={confirming ? 'Confirm delete' : `Delete ${portfolio.name}`}
            className={btn('ghost', cn('h-9 px-3', confirming && 'bg-destructive/20 text-destructive'))}
          >
            <Trash2 aria-hidden="true" />
            {confirming && <span>Confirm</span>}
          </button>
        </div>
      </GlassCard>
    </motion.li>
  )
}

export function DashboardClient() {
  const portfolios = usePortfolios()
  const list = portfolios ? Object.values(portfolios).sort((a, b) => b.updatedAt - a.updatedAt) : []

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h1 className="font-display text-4xl font-semibold tracking-tight">Your portfolios</h1>
          <p className="mt-2 text-muted-foreground">Everything you&apos;ve published from this device.</p>
        </div>
        <Link href="/#upload" className={btn('liquid')}>
          <Plus aria-hidden="true" />
          New portfolio
        </Link>
      </motion.div>

      {portfolios === null ? (
        <div className="grid place-items-center py-24">
          <Loader2 className="size-6 animate-spin text-muted-foreground" aria-label="Loading portfolios" />
        </div>
      ) : list.length === 0 ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <GlassCard className="mt-10 flex flex-col items-center p-12 text-center">
            <span className="grid size-12 place-items-center rounded-2xl bg-liquid text-background">
              <Plus className="size-5" aria-hidden="true" />
            </span>
            <h2 className="mt-5 font-display text-xl font-semibold">No portfolios yet</h2>
            <p className="mt-2 max-w-sm text-sm text-muted-foreground">Upload your resume and publish your first portfolio. It&apos;ll show up right here.</p>
            <Link href="/#upload" className={btn('primary', 'mt-6')}>
              Get started
            </Link>
          </GlassCard>
        </motion.div>
      ) : (
        <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {list.map((p, i) => (
              <PortfolioCard key={p.username} portfolio={p} index={i} />
            ))}
          </AnimatePresence>
        </ul>
      )}
    </div>
  )
}
