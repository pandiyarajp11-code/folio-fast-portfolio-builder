'use client'

import { useRef, useState } from 'react'
import Link from 'next/link'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, Download, Link2, Loader2, Moon, PencilLine, Share2, Sun } from 'lucide-react'
import { toPng } from 'html-to-image'
import { GlassCard, btn } from '@/components/glass'
import { LiquidBackground } from '@/components/liquid-background'
import { PortfolioView } from '@/components/portfolio/portfolio-view'
import { saveDraft, usePortfolio } from '@/lib/storage'
import type { ThemeId } from '@/lib/types'
import { cn } from '@/lib/utils'

export function PublicPortfolio({ username }: { username: string }) {
  const portfolio = usePortfolio(username)
  const [themeOverride, setThemeOverride] = useState<ThemeId | null>(null)
  const [copied, setCopied] = useState(false)
  const [exporting, setExporting] = useState(false)
  const captureRef = useRef<HTMLDivElement>(null)

  if (portfolio === undefined) {
    return (
      <div className="grid min-h-dvh place-items-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" aria-label="Loading portfolio" />
      </div>
    )
  }

  if (portfolio === null) {
    return (
      <div className="grid min-h-dvh place-items-center px-4">
        <LiquidBackground />
        <GlassCard className="max-w-md p-8 text-center">
          <p className="font-mono text-sm text-muted-foreground">/u/{username}</p>
          <h1 className="mt-3 font-display text-3xl font-semibold">Portfolio not found</h1>
          <p className="mt-2 text-sm text-muted-foreground">This portfolio hasn&apos;t been published on this device yet.</p>
          <Link href="/" className={btn('liquid', 'mt-6')}>
            Create yours in 10 seconds
          </Link>
        </GlassCard>
      </div>
    )
  }

  const theme = themeOverride ?? portfolio.theme
  const isDark = theme === 'aurora'

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      window.prompt('Copy this link', window.location.href)
    }
  }

  const share = async () => {
    const payload = { title: `${portfolio.name} — Portfolio`, text: portfolio.title, url: window.location.href }
    if (navigator.share) {
      try {
        await navigator.share(payload)
      } catch {
        // User dismissed the share sheet.
      }
    } else {
      copyLink()
    }
  }

  const downloadPng = async () => {
    const node = captureRef.current
    if (!node) return
    setExporting(true)
    node.setAttribute('data-capturing', '')
    try {
      const dataUrl = await toPng(node, {
        pixelRatio: 2,
        cacheBust: true,
        backgroundColor: isDark ? '#0b0b16' : '#fafbfd',
        width: node.scrollWidth,
        height: node.scrollHeight,
      })
      const a = document.createElement('a')
      a.href = dataUrl
      a.download = `${portfolio.username}-portfolio.png`
      a.click()
    } catch (err) {
      console.error('[foliofast] PNG export failed', err)
    } finally {
      node.removeAttribute('data-capturing')
      setExporting(false)
    }
  }

  const toolbarBtn = cn(
    'flex h-10 items-center gap-2 rounded-xl px-3 text-sm font-medium transition-colors disabled:opacity-50 [&_svg]:size-4',
    isDark ? 'text-white/80 hover:bg-white/10 hover:text-white' : 'text-slate-700 hover:bg-white hover:text-slate-900',
  )
  const toolbarShell = cn(
    'rounded-2xl border shadow-2xl backdrop-blur-xl',
    isDark ? 'border-white/10 bg-[oklch(0.15_0.02_270)]/70' : 'border-white bg-white/70 shadow-slate-900/10',
  )

  return (
    <>
      <div ref={captureRef} className="relative">
        <AnimatePresence mode="wait">
          <motion.div key={theme} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.35 }}>
            <PortfolioView data={portfolio} theme={theme} />
          </motion.div>
        </AnimatePresence>
      </div>

      <motion.button
        type="button"
        onClick={() => setThemeOverride(isDark ? 'minimal' : 'aurora')}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: 1.08, rotate: 12 }}
        whileTap={{ scale: 0.92 }}
        aria-label={isDark ? 'Switch to Minimal Liquid theme' : 'Switch to Dark Aurora theme'}
        className={cn(toolbarShell, 'fixed right-4 top-4 z-50 grid size-12 place-items-center', isDark ? 'text-white' : 'text-slate-800')}
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.span key={theme} initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
            {isDark ? <Sun className="size-5" aria-hidden="true" /> : <Moon className="size-5" aria-hidden="true" />}
          </motion.span>
        </AnimatePresence>
      </motion.button>

      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6, type: 'spring', stiffness: 200, damping: 24 }}
        className={cn(toolbarShell, 'fixed inset-x-0 bottom-4 z-50 mx-auto flex w-fit items-center gap-1 p-1.5')}
        role="toolbar"
        aria-label="Portfolio actions"
      >
        <button type="button" onClick={copyLink} className={toolbarBtn}>
          {copied ? <Check aria-hidden="true" /> : <Link2 aria-hidden="true" />}
          <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy link'}</span>
          <span className="sr-only sm:hidden">{copied ? 'Copied' : 'Copy link'}</span>
        </button>
        <button type="button" onClick={share} className={toolbarBtn}>
          <Share2 aria-hidden="true" />
          <span className="hidden sm:inline">Share</span>
          <span className="sr-only sm:hidden">Share</span>
        </button>
        <button type="button" onClick={downloadPng} disabled={exporting} className={toolbarBtn}>
          {exporting ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Download aria-hidden="true" />}
          <span className="hidden sm:inline">PNG</span>
          <span className="sr-only sm:hidden">Download PNG</span>
        </button>
        <span className={cn('mx-1 h-6 w-px', isDark ? 'bg-white/10' : 'bg-slate-200')} aria-hidden="true" />
        <Link href="/editor" onClick={() => saveDraft(portfolio)} className={toolbarBtn}>
          <PencilLine aria-hidden="true" />
          <span className="hidden sm:inline">Edit</span>
          <span className="sr-only sm:hidden">Edit</span>
        </Link>
      </motion.div>
    </>
  )
}
