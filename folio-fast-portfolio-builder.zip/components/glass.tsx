import { cn } from '@/lib/utils'

export const buttonStyles = {
  base: 'inline-flex items-center justify-center gap-2 rounded-xl text-sm font-medium transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0',
  primary:
    'bg-foreground text-background px-5 h-11 hover:shadow-[0_0_40px_-6px_var(--liquid-violet)] hover:-translate-y-0.5',
  liquid:
    'bg-liquid text-[oklch(0.13_0.02_275)] px-5 h-11 font-semibold hover:shadow-[0_0_50px_-8px_var(--liquid-violet)] hover:-translate-y-0.5',
  ghost: 'glass text-foreground px-4 h-11 hover:bg-white/10',
  subtle: 'text-muted-foreground px-3 h-9 hover:text-foreground hover:bg-white/5',
}

export function btn(variant: keyof Omit<typeof buttonStyles, 'base'> = 'primary', className?: string) {
  return cn(buttonStyles.base, buttonStyles[variant], className)
}

export function GlassCard({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('glass rounded-2xl', className)} {...props} />
}
