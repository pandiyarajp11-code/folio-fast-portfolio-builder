'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion } from 'framer-motion'
import { LayoutGrid, Sparkles } from 'lucide-react'
import { btn } from './glass'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/#features', label: 'Features' },
  { href: '/#themes', label: 'Themes' },
  { href: '/editor', label: 'Editor' },
]

export function SiteHeader() {
  const pathname = usePathname()
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="sticky top-0 z-40 px-4 pt-4"
    >
      <div className="glass mx-auto flex h-14 max-w-6xl items-center justify-between rounded-2xl px-3 pl-4">
        <Link href="/" className="flex items-center gap-2 font-display text-lg font-semibold tracking-tight">
          <span className="grid size-8 place-items-center rounded-lg bg-liquid text-background">
            <Sparkles className="size-4" aria-hidden="true" />
          </span>
          FolioFast
        </Link>
        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground',
                pathname === item.href && 'text-foreground',
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <Link href="/dashboard" className={btn('primary', 'h-9 px-4')}>
          <LayoutGrid aria-hidden="true" />
          <span>Dashboard</span>
        </Link>
      </div>
    </motion.header>
  )
}
