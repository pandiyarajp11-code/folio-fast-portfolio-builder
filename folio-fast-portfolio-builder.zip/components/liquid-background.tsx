'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

type Blob = { className: string; x: number[]; y: number[]; scale: number[]; duration: number }

const DARK_BLOBS: Blob[] = [
  { className: 'left-[-10%] top-[-10%] size-[42rem] bg-liquid-violet/45', x: [0, 120, -40, 0], y: [0, 80, 140, 0], scale: [1, 1.15, 0.95, 1], duration: 22 },
  { className: 'right-[-15%] top-[10%] size-[36rem] bg-liquid-cyan/30', x: [0, -100, 40, 0], y: [0, 120, -40, 0], scale: [1, 0.9, 1.1, 1], duration: 26 },
  { className: 'bottom-[-20%] left-[25%] size-[40rem] bg-liquid-pink/25', x: [0, 80, -120, 0], y: [0, -100, -40, 0], scale: [1, 1.1, 1, 1], duration: 30 },
]

const LIGHT_BLOBS: Blob[] = [
  { className: 'left-[-10%] top-[-10%] size-[40rem] bg-[oklch(0.88_0.08_260)]', x: [0, 100, -30, 0], y: [0, 60, 120, 0], scale: [1, 1.1, 0.95, 1], duration: 24 },
  { className: 'right-[-10%] top-[20%] size-[34rem] bg-[oklch(0.9_0.07_200)]', x: [0, -90, 30, 0], y: [0, 100, -30, 0], scale: [1, 0.92, 1.08, 1], duration: 28 },
  { className: 'bottom-[-15%] left-[30%] size-[36rem] bg-[oklch(0.9_0.07_340)]', x: [0, 70, -100, 0], y: [0, -80, -30, 0], scale: [1, 1.08, 1, 1], duration: 32 },
]

export function LiquidBackground({
  variant = 'dark',
  contained = false,
  className,
}: {
  variant?: 'dark' | 'light'
  contained?: boolean
  className?: string
}) {
  const blobs = variant === 'dark' ? DARK_BLOBS : LIGHT_BLOBS
  return (
    <div
      aria-hidden="true"
      className={cn(
        'pointer-events-none inset-0 -z-10 overflow-hidden',
        contained ? 'absolute' : 'fixed',
        variant === 'dark' ? 'bg-background' : 'bg-[oklch(0.985_0.005_260)]',
        className,
      )}
    >
      {blobs.map((blob, i) => (
        <motion.div
          key={i}
          className={cn('absolute rounded-full blur-[100px] will-change-transform', blob.className)}
          animate={{ x: blob.x, y: blob.y, scale: blob.scale }}
          transition={{ duration: blob.duration, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
      {variant === 'dark' && <div className="absolute inset-0 bg-grid [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />}
      <div
        className={cn(
          'absolute inset-0',
          variant === 'dark'
            ? 'bg-[radial-gradient(ellipse_at_bottom,transparent_40%,var(--background)_95%)]'
            : 'bg-[radial-gradient(ellipse_at_bottom,transparent_50%,oklch(0.985_0.005_260)_100%)]',
        )}
      />
    </div>
  )
}
