'use client'

import { motion } from 'framer-motion'
import { ArrowUpRight, Briefcase, GraduationCap, Mail, MapPin } from 'lucide-react'
import { LiquidBackground } from '@/components/liquid-background'
import { getContactLinks, initials, toHref } from '@/lib/portfolio-utils'
import type { PortfolioData } from '@/lib/types'
import { cn } from '@/lib/utils'

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-60px' },
  transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] as const },
}

const card = 'rounded-2xl border border-white/80 bg-white/55 shadow-[0_10px_40px_-20px_rgba(30,41,99,0.25)] backdrop-blur-xl'

function SectionTitle({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <motion.h2 {...fadeUp} id={id} className="mb-6 scroll-mt-24 font-display text-sm font-medium uppercase tracking-[0.2em] text-slate-500">
      {children}
    </motion.h2>
  )
}

export function ThemeMinimal({ data, embedded = false }: { data: PortfolioData; embedded?: boolean }) {
  const links = getContactLinks(data.contact)
  const sections = [
    data.experience.length > 0 && { id: 'experience', label: 'Experience' },
    data.projects.length > 0 && { id: 'projects', label: 'Projects' },
    data.education.length > 0 && { id: 'education', label: 'Education' },
    { id: 'contact', label: 'Contact' },
  ].filter(Boolean) as { id: string; label: string }[]

  return (
    <div className={cn('relative isolate text-slate-900', embedded ? 'min-h-full overflow-hidden' : 'min-h-dvh')}>
      <LiquidBackground variant="light" contained={embedded} />

      {!embedded && (
        <nav aria-label="Sections" className="sticky top-4 z-30 mx-auto hidden w-fit md:block">
          <ul className={cn(card, 'flex items-center gap-1 rounded-full px-2 py-1.5')}>
            {sections.map((s) => (
              <li key={s.id}>
                <a href={`#${s.id}`} className="rounded-full px-3 py-1.5 text-sm text-slate-600 transition-colors hover:bg-white hover:text-slate-900">
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      )}

      <main className={cn('mx-auto max-w-4xl px-5', embedded ? 'py-12' : 'py-16 md:py-24')}>
        <section className="flex flex-col items-start gap-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className={cn(card, 'grid size-20 place-items-center rounded-3xl font-display text-2xl font-semibold text-slate-800')}
          >
            {initials(data.name)}
          </motion.div>
          <motion.div {...fadeUp} className="flex flex-col gap-3">
            <p className="text-sm font-medium text-slate-500">{data.title}</p>
            <h1 className="text-balance font-display text-5xl font-semibold tracking-tight md:text-7xl">{data.name || 'Your Name'}</h1>
            {data.contact.location && (
              <p className="flex items-center gap-1.5 text-sm text-slate-500">
                <MapPin className="size-4" aria-hidden="true" />
                {data.contact.location}
              </p>
            )}
          </motion.div>
          <motion.p {...fadeUp} className="max-w-2xl text-pretty text-lg leading-relaxed text-slate-600">
            {data.bio}
          </motion.p>
          {data.contact.email && (
            <motion.a
              {...fadeUp}
              href={`mailto:${data.contact.email}`}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-slate-900 px-5 text-sm font-medium text-white transition-transform hover:-translate-y-0.5"
            >
              <Mail className="size-4" aria-hidden="true" />
              Get in touch
            </motion.a>
          )}
        </section>

        {data.skills.length > 0 && (
          <section className="mt-20">
            <SectionTitle id="skills">Skills</SectionTitle>
            <motion.ul {...fadeUp} className="flex flex-wrap gap-2">
              {data.skills.map((skill) => (
                <li key={skill} className={cn(card, 'rounded-full px-4 py-1.5 text-sm text-slate-700')}>
                  {skill}
                </li>
              ))}
            </motion.ul>
          </section>
        )}

        {data.experience.length > 0 && (
          <section className="mt-20">
            <SectionTitle id="experience">Experience</SectionTitle>
            <ol className="flex flex-col gap-4">
              {data.experience.map((exp, i) => (
                <motion.li key={`${exp.role}-${i}`} {...fadeUp} transition={{ ...fadeUp.transition, delay: i * 0.05 }} className={cn(card, 'p-6')}>
                  <div className="flex flex-col justify-between gap-2 md:flex-row md:items-start">
                    <div className="flex items-start gap-3">
                      <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-xl bg-white text-slate-700 shadow-sm">
                        <Briefcase className="size-4" aria-hidden="true" />
                      </span>
                      <div>
                        <h3 className="font-display text-lg font-semibold">{exp.role}</h3>
                        {exp.company && <p className="text-sm text-slate-500">{exp.company}</p>}
                      </div>
                    </div>
                    {exp.period && <span className="text-sm tabular-nums text-slate-500">{exp.period}</span>}
                  </div>
                  {exp.description && <p className="mt-4 text-pretty leading-relaxed text-slate-600">{exp.description}</p>}
                </motion.li>
              ))}
            </ol>
          </section>
        )}

        {data.projects.length > 0 && (
          <section className="mt-20">
            <SectionTitle id="projects">Projects</SectionTitle>
            <div className="grid gap-4 md:grid-cols-2">
              {data.projects.map((project, i) => (
                <motion.article
                  key={`${project.name}-${i}`}
                  {...fadeUp}
                  transition={{ ...fadeUp.transition, delay: i * 0.06 }}
                  whileHover={{ y: -4 }}
                  className={cn(card, 'group flex flex-col p-6')}
                >
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="font-display text-lg font-semibold">{project.name}</h3>
                    {project.link && (
                      <a href={toHref(project.link)} target="_blank" rel="noreferrer" aria-label={`Open ${project.name}`} className="text-slate-400 transition-colors hover:text-slate-900">
                        <ArrowUpRight className="size-5" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                  {project.description && <p className="mt-2 flex-1 text-pretty leading-relaxed text-slate-600">{project.description}</p>}
                  {project.tech.length > 0 && (
                    <ul className="mt-4 flex flex-wrap gap-1.5">
                      {project.tech.map((t) => (
                        <li key={t} className="rounded-md bg-slate-900/5 px-2 py-0.5 text-xs text-slate-600">{t}</li>
                      ))}
                    </ul>
                  )}
                </motion.article>
              ))}
            </div>
          </section>
        )}

        {data.education.length > 0 && (
          <section className="mt-20">
            <SectionTitle id="education">Education</SectionTitle>
            <div className="flex flex-col gap-4">
              {data.education.map((edu, i) => (
                <motion.div key={`${edu.degree}-${i}`} {...fadeUp} className={cn(card, 'flex items-start gap-3 p-6')}>
                  <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-white text-slate-700 shadow-sm">
                    <GraduationCap className="size-4" aria-hidden="true" />
                  </span>
                  <div className="flex flex-1 flex-col justify-between gap-1 md:flex-row">
                    <div>
                      <h3 className="font-display font-semibold">{edu.degree || edu.school}</h3>
                      {edu.degree && edu.school && <p className="text-sm text-slate-500">{edu.school}</p>}
                    </div>
                    {edu.period && <span className="text-sm tabular-nums text-slate-500">{edu.period}</span>}
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        <section className="mt-20">
          <SectionTitle id="contact">Contact</SectionTitle>
          <motion.div {...fadeUp} className={cn(card, 'p-8')}>
            <p className="font-display text-3xl font-semibold tracking-tight text-balance">{"Let's build something great together."}</p>
            {links.length > 0 && (
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {links.map((link) => (
                  <li key={link.key}>
                    <a
                      href={link.href}
                      target={link.key === 'email' || link.key === 'phone' ? undefined : '_blank'}
                      rel="noreferrer"
                      className="flex items-center justify-between rounded-xl bg-white/70 px-4 py-3 text-sm transition-colors hover:bg-white"
                    >
                      <span className="text-slate-500">{link.label}</span>
                      <span className="truncate pl-4 font-medium text-slate-800">{link.value}</span>
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </motion.div>
          <p className="mt-10 text-center text-xs text-slate-400">Built with FolioFast</p>
        </section>
      </main>
    </div>
  )
}
