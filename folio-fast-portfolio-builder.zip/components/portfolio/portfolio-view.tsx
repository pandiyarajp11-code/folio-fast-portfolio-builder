'use client'

import type { PortfolioData, ThemeId } from '@/lib/types'
import { ThemeAurora } from './theme-aurora'
import { ThemeMinimal } from './theme-minimal'

export const THEMES: { id: ThemeId; name: string; description: string }[] = [
  { id: 'minimal', name: 'Minimal Liquid', description: 'White glass, soft pastels, calm scroll.' },
  { id: 'aurora', name: 'Dark Aurora', description: 'Deep night with neon liquid gradients.' },
]

export function PortfolioView({ data, theme, embedded }: { data: PortfolioData; theme: ThemeId; embedded?: boolean }) {
  return theme === 'minimal' ? <ThemeMinimal data={data} embedded={embedded} /> : <ThemeAurora data={data} embedded={embedded} />
}
