'use client'

import { motion } from 'framer-motion'
import { ArrowUpRight, Mail, MapPin } from 'lucide-react'
import { getContactLinks, initials, toHref } from '@/lib/portfolio-utils'
import type { PortfolioData } from '@/lib/types'
import { cn } from '@/lib/utils'

const fadeUp = {
  initial: { opacity: 0, y: 28, filter: 'blur(8px)' },
  whileInView: { opacity: 1, y: 0, filter: 'blur(0px)' },
  viewport: { once: true, margin: '-60px' },
  transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] as const },
}

const card =
  'rounded-2xl border border-white/10 bg-white/[0.04] shadow-[inset_0_1px_0_0_rgba(255,255,255,0.08)] backdrop-blur-xl'

function AuroraBackdrop({ embedded }: { embedded: boolean }) {
  const ribbons = [
    { cls: 'left-[-20%] top-[-20%] h-[30rem] w-[60rem] bg-[oklch(0.75_0.2_160)]/35', rotate: [-12, 6, -12], x: [0, 120, 0] },
    { cls: 'right-[-25%] top-[0%] h-[26rem] w-[55rem] bg-[oklch(0.65_0.27_300)]/40', rotate: [10, -8, 10], x: [0, -140, 0] },
    { cls: 'left-[10%] top-[35%] h-[22rem] w-[50rem] bg-[oklch(0.78_0.16_210)]/25', rotate: [-4, 10, -4], x: [0, 90, 0] },
  ]
  return (
    <div aria-hidden="true" className={cn('pointer-events-none inset-0 -z-10 overflow-hidden bg-[oklch(0.1_0.02_270)]', embedded ? 'absolute' : 'fixed')}>
      {ribbons.map((r, i) => (
        <motion.div
          key={i}
          className={cn('absolute rounded-full blur-[110px] will-change-transform', r.cls)}
          animate={{ rotate: r.rotate, x: r.x }}
          transition={{ duration: 18 + i * 5, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,transparent_30%,oklch(0.1_0.02_270)_85%)]" />
    </div>
  )
}

function SectionTitle({ id, index, children }: { id: string; index: string; children: React.ReactNode }) {
  return (
    <motion.div {...fadeUp} className="mb-8 flex items-baseline gap-4">
      <span className="font-mono text-xs text-[oklch(0.82_0.15_180)]">{index}</span>
      <h2 id={id} className="scroll-mt-24 font-display text-3xl font-semibold tracking-tight md:text-4xl">
        {children}
      </h2>
      <span className="h-px flex-1 bg-gradient-to-r from-white/20 to-transparent" />
    </motion.div>
  )
}

export function ThemeAurora({ data, embedded = false }: { data: PortfolioData; embedded?: boolean }) {
  const links = getContactLinks(data.contact)
  let counter = 0
  const nextIndex = () => String(++counter).padStart(2, '0')

  return (
    <div className={cn('relative isolate text-white', embedded ? 'min-h-full overflow-hidden' : 'min-h-dvh')}>
      <AuroraBackdrop embedded={embedded} />

      <main className={cn('mx-auto max-w-5xl px-5', embedded ? 'py-12' : 'py-20 md:py-28')}>
        <section className="relative">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className={cn(card, 'inline-flex items-center gap-3 rounded-full py-1.5 pl-1.5 pr-4')}
          >
            <span className="grid size-8 place-items-center rounded-full bg-gradient-to-br from-[oklch(0.8_0.17_170)] to-[oklch(0.65_0.27_300)] text-xs font-bold text-[oklch(0.1_0.02_270)]">
              {initials(data.name)}
            </span>
            <span className="flex items-center gap-2 text-sm text-white/70">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-[oklch(0.8_0.17_160)] opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-[oklch(0.8_0.17_160)]" />
              </span>
              Available for opportunities
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30, filter: 'blur(12px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
            className="mt-8 text-balance font-display text-5xl font-bold leading-[0.95] tracking-tighter md:text-8xl"
          >
            <span className="bg-gradient-to-br from-white via-white to-white/50 bg-clip-text text-transparent">{data.name || 'Your Name'}</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35, duration: 0.8 }}
            className="mt-5 bg-gradient-to-r from-[oklch(0.82_0.15_180)] via-[oklch(0.72_0.2_290)] to-[oklch(0.75_0.2_345)] bg-clip-text font-display text-xl font-medium text-transparent md:text-2xl"
          >
            {data.title}
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.8 }}
            className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-white/65"
          >
            {data.bio}
          </motion.p>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="mt-8 flex flex-wrap items-center gap-3">
            {data.contact.email && (
              <a
                href={`mailto:${data.contact.email}`}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-gradient-to-r from-[oklch(0.82_0.15_180)] to-[oklch(0.7_0.22_295)] px-5 text-sm font-semibold text-[oklch(0.1_0.02_270)] transition-all hover:-translate-y-0.5 hover:shadow-[0_0_40px_-5px_oklch(0.7_0.22_295)]"
              >
                <Mail className="size-4" aria-hidden="true" />
                Contact me
              </a>
            )}
            {data.contact.location && (
              <span className="flex items-center gap-1.5 text-sm text-white/55">
                <MapPin className="size-4" aria-hidden="true" />
                {data.contact.location}
              </span>
            )}
          </motion.div>
        </section>

        {data.skills.length > 0 && (
          <section className="mt-28">
            <SectionTitle id="skills" index={nextIndex()}>Stack</SectionTitle>
            <motion.ul
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              variants={{ hidden: {}, show: { transition: { staggerChildren: 0.035 } } }}
              className="flex flex-wrap gap-2"
            >
              {data.skills.map((skill) => (
                <motion.li
                  key={skill}
                  variants={{ hidden: { opacity: 0, scale: 0.8 }, show: { opacity: 1, scale: 1 } }}
                  className={cn(card, 'rounded-xl px-4 py-2 text-sm text-white/85 transition-colors hover:border-[oklch(0.82_0.15_180)]/50 hover:text-white')}
                >
                  {skill}
                </motion.li>
              ))}
            </motion.ul>
          </section>
        )}

        {data.experience.length > 0 && (
          <section className="mt-28">
            <SectionTitle id="experience" index={nextIndex()}>Experience</SectionTitle>
            <ol className="relative flex flex-col gap-6 border-l border-white/10 pl-6 md:pl-8">
              {data.experience.map((exp, i) => (
                <motion.li key={`${exp.role}-${i}`} {...fadeUp} className="relative">
                  <span className="absolute -left-[31px] top-2 size-3 rounded-full bg-[oklch(0.82_0.15_180)] shadow-[0_0_16px_oklch(0.82_0.15_180)] md:-left-[39px]" />
                  <div className={cn(card, 'p-6')}>
                    <div className="flex flex-col justify-between gap-1 md:flex-row md:items-baseline">
                      <h3 className="font-display text-xl font-semibold">
                        {exp.role}
                        {exp.company && <span className="text-white/50"> · {exp.company}</span>}
                      </h3>
                      {exp.period && <span className="font-mono text-xs uppercase tracking-wider text-white/45">{exp.period}</span>}
                    </div>
                    {exp.description && <p className="mt-3 text-pretty leading-relaxed text-white/60">{exp.description}</p>}
                  </div>
                </motion.li>
              ))}
            </ol>
          </section>
        )}

        {data.projects.length > 0 && (
          <section className="mt-28">
            <SectionTitle id="projects" index={nextIndex()}>Selected work</SectionTitle>
            <div className="grid gap-5 md:grid-cols-2">
              {data.projects.map((project, i) => (
                <motion.article
                  key={`${project.name}-${i}`}
                  {...fadeUp}
                  transition={{ ...fadeUp.transition, delay: (i % 2) * 0.1 }}
                  whileHover={{ y: -6 }}
                  className={cn(card, 'group relative flex flex-col overflow-hidden p-6')}
                >
                  <div className="pointer-events-none absolute -right-20 -top-20 size-48 rounded-full bg-[oklch(0.65_0.27_300)]/0 blur-3xl transition-colors duration-500 group-hover:bg-[oklch(0.65_0.27_300)]/40" />
                  <div className="relative flex items-start justify-between gap-4">
                    <h3 className="font-display text-xl font-semibold">{project.name}</h3>
                    {project.link && (
                      <a href={toHref(project.link)} target="_blank" rel="noreferrer" aria-label={`Open ${project.name}`} className="text-white/40 transition-colors hover:text-white">
                        <ArrowUpRight className="size-5" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                  {project.description && <p className="relative mt-3 flex-1 text-pretty leading-relaxed text-white/60">{project.description}</p>}
                  {project.tech.length > 0 && (
                    <ul className="relative mt-5 flex flex-wrap gap-1.5">
                      {project.tech.map((t) => (
                        <li key={t} className="rounded-md border border-white/10 px-2 py-0.5 font-mono text-[11px] text-[oklch(0.82_0.15_180)]">{t}</li>
                      ))}
                    </ul>
                  )}
                </motion.article>
              ))}
            </div>
          </section>
        )}

        {data.education.length > 0 && (
          <section className="mt-28">
            <SectionTitle id="education" index={nextIndex()}>Education</SectionTitle>
            <div className="grid gap-4 md:grid-cols-2">
              {data.education.map((edu, i) => (
                <motion.div key={`${edu.degree}-${i}`} {...fadeUp} className={cn(card, 'p-6')}>
                  {edu.period && <p className="font-mono text-xs text-white/45">{edu.period}</p>}
                  <h3 className="mt-2 font-display text-lg font-semibold">{edu.degree || edu.school}</h3>
                  {edu.degree && edu.school && <p className="mt-1 text-sm text-white/55">{edu.school}</p>}
                </motion.div>
              ))}
            </div>
          </section>
        )}

        <section className="mt-28">
          <motion.div {...fadeUp} className={cn(card, 'relative overflow-hidden p-8 md:p-12')}>
            <div className="pointer-events-none absolute -bottom-32 left-1/2 h-64 w-[40rem] -translate-x-1/2 rounded-full bg-gradient-to-r from-[oklch(0.75_0.2_160)]/40 via-[oklch(0.65_0.27_300)]/40 to-[oklch(0.75_0.2_345)]/40 blur-3xl" />
            <h2 id="contact" className="relative text-balance font-display text-4xl font-bold tracking-tight md:text-5xl">
              {"Let's create something remarkable."}
            </h2>
            {links.length > 0 && (
              <ul className="relative mt-8 flex flex-wrap gap-3">
                {links.map((link) => (
                  <li key={link.key}>
                    <a
                      href={link.href}
                      target={link.key === 'email' || link.key === 'phone' ? undefined : '_blank'}
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white/80 transition-all hover:border-white/30 hover:bg-white/10 hover:text-white"
                    >
                      {link.label}
                      <ArrowUpRight className="size-3.5" aria-hidden="true" />
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </motion.div>
          <p className="mt-10 text-center text-xs text-white/35">Built with FolioFast</p>
        </section>
      </main>
    </div>
  )
}
