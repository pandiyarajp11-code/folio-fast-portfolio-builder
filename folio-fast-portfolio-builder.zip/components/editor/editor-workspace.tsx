'use client'

import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { AnimatePresence, motion } from 'framer-motion'
import { AlertCircle, Check, Code2, Eye, Loader2, Rocket, Save, WandSparkles } from 'lucide-react'
import { btn } from '@/components/glass'
import { PortfolioView, THEMES } from '@/components/portfolio/portfolio-view'
import { normalizePortfolio } from '@/lib/portfolio-utils'
import { getPortfolios, publishPortfolio, saveDraft } from '@/lib/storage'
import type { PortfolioData, ThemeId } from '@/lib/types'
import { cn } from '@/lib/utils'

type ParseResult = { ok: true; data: PortfolioData } | { ok: false; error: string }

function parse(text: string): ParseResult {
  try {
    return { ok: true, data: normalizePortfolio(JSON.parse(text)) }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'Invalid JSON' }
  }
}

export function EditorWorkspace({ initial }: { initial: PortfolioData }) {
  const router = useRouter()
  const [text, setText] = useState(() => JSON.stringify(initial, null, 2))
  const [lastValid, setLastValid] = useState<PortfolioData>(initial)
  const [publishedAs] = useState(() => (getPortfolios()[initial.username] ? initial.username : undefined))
  const [mobileView, setMobileView] = useState<'edit' | 'preview'>('edit')
  const [saveState, setSaveState] = useState<'idle' | 'saved'>('idle')
  const [publishing, setPublishing] = useState(false)
  const [publishError, setPublishError] = useState('')

  const result = useMemo(() => parse(text), [text])
  const preview = result.ok ? result.data : lastValid

  const updateText = (value: string) => {
    setText(value)
    setSaveState('idle')
    setPublishError('')
    const next = parse(value)
    if (next.ok) setLastValid(next.data)
  }

  const setTheme = (theme: ThemeId) => {
    if (!result.ok) {
      setLastValid({ ...lastValid, theme })
      return
    }
    updateText(JSON.stringify({ ...JSON.parse(text), theme }, null, 2))
  }

  const handleSave = () => {
    if (!result.ok) return
    saveDraft(result.data)
    setSaveState('saved')
  }

  const handlePublish = () => {
    if (!result.ok) return
    const data = result.data
    if (!data.username || data.username.length < 3) {
      setPublishError('Username must be at least 3 characters (a–z, 0–9, -).')
      return
    }
    const existing = getPortfolios()[data.username]
    if (existing && data.username !== publishedAs) {
      setPublishError(`/u/${data.username} is already taken by another portfolio on this device.`)
      return
    }
    setPublishing(true)
    publishPortfolio(data, publishedAs)
    router.push(`/u/${data.username}`)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault()
      const el = e.currentTarget
      const { selectionStart: start, selectionEnd: end } = el
      const next = `${text.slice(0, start)}  ${text.slice(end)}`
      updateText(next)
      requestAnimationFrame(() => el.setSelectionRange(start + 2, start + 2))
    }
    if ((e.metaKey || e.ctrlKey) && e.key === 's') {
      e.preventDefault()
      handleSave()
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-[1600px] flex-1 flex-col gap-4 px-4 pb-4 pt-6">
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col justify-between gap-4 md:flex-row md:items-center"
      >
        <div>
          <h1 className="font-display text-2xl font-semibold tracking-tight">Edit your portfolio</h1>
          <p className="text-sm text-muted-foreground">
            Publishing to <span className="font-mono text-foreground">/u/{preview.username || '…'}</span>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="glass flex rounded-xl p-1 lg:hidden" role="tablist" aria-label="Editor view">
            {(['edit', 'preview'] as const).map((v) => (
              <button
                key={v}
                role="tab"
                aria-selected={mobileView === v}
                onClick={() => setMobileView(v)}
                className={cn('flex h-9 items-center gap-1.5 rounded-lg px-3 text-sm capitalize transition-colors', mobileView === v ? 'bg-white/10 text-foreground' : 'text-muted-foreground')}
              >
                {v === 'edit' ? <Code2 className="size-4" aria-hidden="true" /> : <Eye className="size-4" aria-hidden="true" />}
                {v}
              </button>
            ))}
          </div>
          <button type="button" onClick={handleSave} disabled={!result.ok} className={btn('ghost')}>
            {saveState === 'saved' ? <Check aria-hidden="true" /> : <Save aria-hidden="true" />}
            {saveState === 'saved' ? 'Saved' : 'Save'}
          </button>
          <button type="button" onClick={handlePublish} disabled={!result.ok || publishing} className={btn('liquid')}>
            {publishing ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Rocket aria-hidden="true" />}
            Publish
          </button>
        </div>
      </motion.div>

      <AnimatePresence>
        {publishError && (
          <motion.p
            role="alert"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex items-center gap-2 text-sm text-destructive"
          >
            <AlertCircle className="size-4" aria-hidden="true" />
            {publishError}
          </motion.p>
        )}
      </AnimatePresence>

      <div className="grid min-h-0 flex-1 gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <motion.section
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          aria-label="JSON editor"
          className={cn('glass flex h-[calc(100dvh-13rem)] min-h-[28rem] flex-col overflow-hidden rounded-2xl', mobileView === 'preview' && 'hidden lg:flex')}
        >
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
            <div className="flex items-center gap-2 text-sm">
              <Code2 className="size-4 text-liquid-cyan" aria-hidden="true" />
              <span className="font-mono">portfolio.json</span>
            </div>
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  'flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs',
                  result.ok ? 'bg-emerald-400/10 text-emerald-300' : 'bg-destructive/15 text-destructive',
                )}
              >
                <span className={cn('size-1.5 rounded-full', result.ok ? 'bg-emerald-300' : 'bg-destructive')} />
                {result.ok ? 'Valid' : 'Invalid JSON'}
              </span>
              <button
                type="button"
                disabled={!result.ok}
                onClick={() => result.ok && updateText(JSON.stringify(result.data, null, 2))}
                className={btn('subtle', 'h-7 px-2 text-xs')}
              >
                <WandSparkles aria-hidden="true" />
                Format
              </button>
            </div>
          </div>
          <label htmlFor="json-editor" className="sr-only">
            Portfolio JSON
          </label>
          <textarea
            id="json-editor"
            value={text}
            onChange={(e) => updateText(e.target.value)}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoCorrect="off"
            className="flex-1 resize-none bg-transparent p-4 font-mono text-[13px] leading-relaxed text-foreground/90 outline-none selection:bg-liquid-violet/30"
          />
          {!result.ok && <p className="truncate border-t border-white/10 px-4 py-2 font-mono text-xs text-destructive">{result.error}</p>}
        </motion.section>

        <motion.section
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1], delay: 0.05 }}
          aria-label="Live preview"
          className={cn('glass flex h-[calc(100dvh-13rem)] min-h-[28rem] flex-col overflow-hidden rounded-2xl', mobileView === 'edit' && 'hidden lg:flex')}
        >
          <div className="flex items-center justify-between gap-2 border-b border-white/10 px-4 py-2">
            <div className="flex items-center gap-2 text-sm">
              <Eye className="size-4 text-liquid-pink" aria-hidden="true" />
              Live preview
            </div>
            <div className="flex rounded-lg bg-white/5 p-0.5" role="radiogroup" aria-label="Theme">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  role="radio"
                  aria-checked={preview.theme === t.id}
                  onClick={() => setTheme(t.id)}
                  className={cn('relative rounded-md px-3 py-1.5 text-xs transition-colors', preview.theme === t.id ? 'text-foreground' : 'text-muted-foreground hover:text-foreground')}
                >
                  {preview.theme === t.id && <motion.span layoutId="editor-theme-pill" className="absolute inset-0 rounded-md bg-white/10" />}
                  <span className="relative">{t.name}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="relative flex-1 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div key={preview.theme} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }} className="min-h-full">
                <PortfolioView data={preview} theme={preview.theme} embedded />
              </motion.div>
            </AnimatePresence>
          </div>
        </motion.section>
      </div>
    </div>
  )
}
