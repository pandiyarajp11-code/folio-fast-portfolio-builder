'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { FileUp, Loader2 } from 'lucide-react'
import { GlassCard, btn } from '@/components/glass'
import { useDraft } from '@/lib/storage'
import { EditorWorkspace } from './editor-workspace'

export function EditorClient() {
  const draft = useDraft()

  if (draft === undefined) {
    return (
      <div className="grid flex-1 place-items-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" aria-label="Loading editor" />
      </div>
    )
  }

  if (draft === null) {
    return (
      <div className="grid flex-1 place-items-center px-4 py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard className="max-w-md p-8 text-center">
            <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-liquid text-background">
              <FileUp className="size-5" aria-hidden="true" />
            </span>
            <h1 className="mt-5 font-display text-2xl font-semibold">No resume yet</h1>
            <p className="mt-2 text-sm text-muted-foreground">Upload a PDF resume first and we&apos;ll turn it into an editable portfolio.</p>
            <Link href="/#upload" className={btn('liquid', 'mt-6')}>
              Upload resume
            </Link>
          </GlassCard>
        </motion.div>
      </div>
    )
  }

  return <EditorWorkspace initial={draft} />
}
