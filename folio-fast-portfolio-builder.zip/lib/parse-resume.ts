import type { Education, Experience, PortfolioData, Project } from './types'

const SKILL_KEYWORDS = [
  'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'Golang', 'Rust', 'Ruby', 'PHP', 'Swift',
  'Kotlin', 'Dart', 'Scala', 'SQL', 'HTML', 'CSS', 'Sass', 'Tailwind', 'React', 'React Native',
  'Next.js', 'Vue', 'Nuxt', 'Angular', 'Svelte', 'Redux', 'Node.js', 'Express', 'NestJS', 'Django',
  'Flask', 'FastAPI', 'Spring', 'Spring Boot', 'Laravel', 'Rails', '.NET', 'GraphQL', 'REST',
  'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'SQLite', 'Firebase', 'Supabase', 'Prisma', 'AWS',
  'Azure', 'GCP', 'Docker', 'Kubernetes', 'Terraform', 'Linux', 'Git', 'GitHub', 'CI/CD', 'Jenkins',
  'Flutter', 'TensorFlow', 'PyTorch', 'Pandas', 'NumPy', 'Scikit-learn', 'Machine Learning',
  'Deep Learning', 'NLP', 'Data Analysis', 'Power BI', 'Tableau', 'Excel', 'Figma', 'Photoshop',
  'Illustrator', 'UI/UX', 'Jest', 'Cypress', 'Playwright', 'Webpack', 'Vite', 'Three.js', 'Kafka',
  'Elasticsearch', 'Agile', 'Scrum', 'Jira', 'Selenium', 'OpenCV', 'LLM', 'Generative AI',
]

const SECTION_PATTERNS: Record<string, RegExp> = {
  summary: /^(summary|profile|about( me)?|objective|professional summary|career objective|overview)$/i,
  experience: /^(experience|work experience|professional experience|employment( history)?|work history|internships?)$/i,
  projects: /^(projects?|personal projects|academic projects|key projects|selected projects)$/i,
  education: /^(education|academics?|academic background|qualifications?)$/i,
  skills: /^(skills|technical skills|core skills|key skills|technologies|tech stack|core competencies)$/i,
  other: /^(certifications?|achievements|awards|languages|interests|hobbies|references|publications|activities|declaration)$/i,
}

const EMAIL_RE = /[\w.+-]+@[\w-]+\.[\w.-]+/
const PHONE_RE = /(\+?\d[\d\s().-]{8,}\d)/
const LINKEDIN_RE = /(?:https?:\/\/)?(?:www\.)?linkedin\.com\/[\w\-/]+/i
const GITHUB_RE = /(?:https?:\/\/)?(?:www\.)?github\.com\/[\w\-]+/i
const URL_RE = /(?:https?:\/\/)?(?:www\.)?[a-z0-9-]+\.(?:dev|io|me|com|app|site|in|net|org|tech)(?:\/[\w\-/]*)?/i
const MONTH = '(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\\.?'
const DATE_RANGE_RE = new RegExp(
  `((?:${MONTH}\\s*)?(?:19|20)\\d{2}\\s*(?:-|–|—|to)\\s*(?:(?:${MONTH}\\s*)?(?:19|20)\\d{2}|present|current|now))`,
  'i',
)
const YEAR_RE = /\b(?:19|20)\d{2}\b/
const BULLET_RE = /^[•●▪◦■\-*–·]\s*/
const DEGREE_RE =
  /\b(b\.?\s?tech|m\.?\s?tech|b\.?\s?e\b|m\.?\s?e\b|b\.?\s?sc|m\.?\s?sc|bca|mca|mba|bba|ph\.?\s?d|bachelor|master|diploma|associate|degree|hsc|ssc|high school|secondary)/i
const SCHOOL_RE = /\b(university|college|institute|school|academy|iit|nit)\b/i

function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function detectSection(line: string): string | null {
  const clean = line.replace(/[:|]/g, '').trim()
  if (clean.length > 40) return null
  for (const [key, re] of Object.entries(SECTION_PATTERNS)) {
    if (re.test(clean)) return key
  }
  return null
}

function splitSections(lines: string[]) {
  const sections: Record<string, string[]> = { header: [] }
  let current = 'header'
  for (const line of lines) {
    const section = detectSection(line)
    if (section) {
      current = section
      sections[current] ??= []
      continue
    }
    sections[current] ??= []
    sections[current].push(line)
  }
  return sections
}

function extractSkills(text: string, skillLines: string[]) {
  const found = new Set<string>()
  for (const skill of SKILL_KEYWORDS) {
    const pattern = new RegExp(`(^|[^\\w+#.])${escapeRegex(skill)}(?![\\w+#])`, skill.length <= 2 ? '' : 'i')
    if (pattern.test(text)) found.add(skill)
  }
  for (const line of skillLines) {
    const body = line.includes(':') ? line.split(':').slice(1).join(':') : line
    body
      .split(/[,|•·;\/]/)
      .map((s) => s.replace(BULLET_RE, '').trim())
      .filter((s) => s.length > 1 && s.length < 28 && !/\d{4}/.test(s))
      .forEach((s) => {
        const exists = [...found].some((f) => f.toLowerCase() === s.toLowerCase())
        if (!exists) found.add(s)
      })
  }
  return [...found].slice(0, 24)
}

function parseExperience(lines: string[]): Experience[] {
  const entries: Experience[] = []
  let current: Experience | null = null
  let pendingTitle = ''

  const push = () => {
    if (current && (current.role || current.company)) {
      current.description = current.description.trim()
      entries.push(current)
    }
  }

  for (const raw of lines) {
    const line = raw.trim()
    if (!line) continue
    const isBullet = BULLET_RE.test(line)
    const dateMatch = line.match(DATE_RANGE_RE)

    if (dateMatch && !isBullet) {
      push()
      const rest = line.replace(dateMatch[0], '').replace(/[|,–—-]\s*$/, '').trim()
      const titleSource = rest || pendingTitle
      const [role, company] = titleSource.split(/\s+(?:at|@|\||–|—|-|,)\s+/)
      current = {
        role: (role ?? titleSource).trim(),
        company: (company ?? (rest && pendingTitle ? pendingTitle : '')).trim(),
        period: dateMatch[0].trim(),
        description: '',
      }
      pendingTitle = ''
      continue
    }

    if (isBullet || line.length > 70) {
      if (current) current.description += `${line.replace(BULLET_RE, '')} `
      continue
    }

    if (current && !current.company && current.description === '') {
      current.company = line
    } else {
      pendingTitle = line
    }
  }
  push()
  return entries.slice(0, 8)
}

function parseProjects(lines: string[]): Project[] {
  const projects: Project[] = []
  let current: Project | null = null

  for (const raw of lines) {
    const line = raw.trim()
    if (!line) continue
    const isBullet = BULLET_RE.test(line)
    if (!isBullet && line.length <= 70) {
      if (current) projects.push(current)
      const [name, techPart] = line.split(/\s+[|–—]\s+|:\s+/)
      const link = line.match(GITHUB_RE)?.[0] ?? line.match(/https?:\/\/\S+/)?.[0] ?? ''
      current = {
        name: name.replace(link, '').trim(),
        description: '',
        tech: techPart
          ? techPart.split(/[,/]/).map((t) => t.trim()).filter((t) => t && t.length < 24)
          : [],
        link,
      }
    } else if (current) {
      current.description += `${line.replace(BULLET_RE, '')} `
    } else {
      current = { name: 'Project', description: `${line.replace(BULLET_RE, '')} `, tech: [], link: '' }
    }
  }
  if (current) projects.push(current)
  return projects
    .map((p) => ({ ...p, description: p.description.trim() }))
    .filter((p) => p.name)
    .slice(0, 8)
}

function parseEducation(lines: string[]): Education[] {
  const entries: Education[] = []
  let current: Education | null = null

  for (const raw of lines) {
    const line = raw.replace(BULLET_RE, '').trim()
    if (!line) continue
    const period = line.match(DATE_RANGE_RE)?.[0] ?? line.match(YEAR_RE)?.[0] ?? ''
    const text = period ? line.replace(period, '').replace(/[|,–—-]\s*$/, '').trim() : line

    if (DEGREE_RE.test(text)) {
      if (current) entries.push(current)
      current = { degree: text, school: '', period }
    } else if (SCHOOL_RE.test(text)) {
      if (current && !current.school) {
        current.school = text
        if (!current.period) current.period = period
      } else {
        if (current) entries.push(current)
        current = { degree: '', school: text, period }
      }
    } else if (current && !current.period && period) {
      current.period = period
    }
  }
  if (current) entries.push(current)
  return entries.slice(0, 5)
}

function guessName(headerLines: string[], allLines: string[]) {
  const candidates = headerLines.length ? headerLines : allLines
  for (const line of candidates.slice(0, 6)) {
    const clean = line.trim()
    if (!clean || EMAIL_RE.test(clean) || PHONE_RE.test(clean) || /https?:|www\./i.test(clean)) continue
    const words = clean.split(/\s+/)
    if (words.length <= 5 && /^[A-Za-z][A-Za-z.'\s-]+$/.test(clean)) {
      return clean
        .toLowerCase()
        .replace(/\b\w/g, (c) => c.toUpperCase())
    }
  }
  return 'Your Name'
}

function guessTitle(headerLines: string[], name: string) {
  const titleRe = /(developer|engineer|designer|analyst|manager|scientist|student|consultant|architect|intern|specialist|lead|founder|freelancer)/i
  const line = headerLines.find((l) => l.trim().toLowerCase() !== name.toLowerCase() && titleRe.test(l) && l.length < 70)
  return line?.replace(/[|•].*$/, '').trim() ?? 'Software Developer'
}

export function generateUsername(name: string, taken: string[] = []) {
  const base =
    name
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[^a-z\s]/g, '')
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .join('')
      .slice(0, 20) || 'folio'
  for (let i = 0; i < 50; i++) {
    const candidate = `${base}${Math.floor(10 + Math.random() * 90)}`
    if (!taken.includes(candidate)) return candidate
  }
  return `${base}${Date.now().toString().slice(-5)}`
}

export function parseResumeText(text: string, takenUsernames: string[] = []): PortfolioData {
  const lines = text
    .split('\n')
    .map((l) => l.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
  const sections = splitSections(lines)
  const header = sections.header ?? []

  const name = guessName(header, lines)
  const email = text.match(EMAIL_RE)?.[0] ?? ''
  const phone = text.match(PHONE_RE)?.[0]?.trim() ?? ''
  const linkedin = text.match(LINKEDIN_RE)?.[0] ?? ''
  const github = text.match(GITHUB_RE)?.[0] ?? ''
  const website =
    header
      .map((l) => l.match(URL_RE)?.[0] ?? '')
      .find((u) => u && !/linkedin|github|gmail|yahoo|outlook|hotmail/i.test(u)) ?? ''
  const location =
    header.find((l) => /^[A-Z][a-zA-Z\s]+,\s*[A-Z][a-zA-Z\s]+$/.test(l) && l.length < 40) ?? ''

  const summary = (sections.summary ?? []).join(' ').trim()
  const title = guessTitle(header, name)

  let projectLines = sections.projects ?? []
  if (!projectLines.length) {
    projectLines = lines.filter((l) => /project/i.test(l) && !detectSection(l))
  }

  const skills = extractSkills(text, sections.skills ?? [])

  return {
    username: generateUsername(name, takenUsernames),
    name,
    title,
    bio:
      summary ||
      `${title} passionate about building thoughtful products${skills.length ? ` with ${skills.slice(0, 3).join(', ')}` : ''}.`,
    skills,
    projects: parseProjects(projectLines),
    experience: parseExperience(sections.experience ?? []),
    education: parseEducation(sections.education ?? []),
    contact: { email, phone, location, website, linkedin, github },
    theme: 'aurora',
  }
}

type PdfTextItem = { str: string; transform: number[]; hasEOL?: boolean }

export async function extractTextFromPdf(file: File): Promise<string> {
  const pdfjs = await import('pdfjs-dist')
  pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs'

  const buffer = await file.arrayBuffer()
  const pdf = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise
  const pages: string[] = []

  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum)
    const content = await page.getTextContent()
    const rows = new Map<number, { x: number; str: string }[]>()

    for (const raw of content.items) {
      const item = raw as PdfTextItem
      if (!('str' in item) || !item.str.trim()) continue
      const y = Math.round(item.transform[5] / 3) * 3
      const x = item.transform[4]
      const row = rows.get(y) ?? []
      row.push({ x, str: item.str })
      rows.set(y, row)
    }

    const pageText = [...rows.entries()]
      .sort((a, b) => b[0] - a[0])
      .map(([, row]) =>
        row
          .sort((a, b) => a.x - b.x)
          .map((r) => r.str)
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim(),
      )
      .join('\n')
    pages.push(pageText)
  }

  return pages.join('\n')
}

export const SAMPLE_RESUME_TEXT = `Pandiyaraj Kumar
Full Stack Developer
Chennai, India
pandiyaraj.dev@gmail.com | +91 98765 43210 | github.com/pandiyaraj | linkedin.com/in/pandiyaraj
Summary
Full stack developer with 4+ years of experience crafting fast, delightful web products. I love turning complex problems into simple, beautiful interfaces and scalable APIs.
Skills
Languages: JavaScript, TypeScript, Python, SQL
Frameworks: React, Next.js, Node.js, Express, Tailwind
Tools: Docker, AWS, PostgreSQL, MongoDB, Git, Figma
Experience
Senior Frontend Engineer at Lumen Labs Jan 2023 - Present
• Led the rebuild of the core dashboard in Next.js, cutting load time by 48%.
• Mentored 5 engineers and introduced a shared design system used across 3 products.
Software Engineer at Brightwave Technologies Jun 2021 - Dec 2022
• Built real-time collaboration features with WebSockets for 20k+ daily users.
• Designed REST and GraphQL APIs in Node.js backed by PostgreSQL.
Projects
FolioFlow | Next.js, Tailwind, Framer Motion
• A portfolio generator that converts resumes into elegant websites in seconds.
PulseChat | React, Node.js, Redis
• Real-time team chat with presence, threads, and end-to-end message search.
Visionary AI | Python, PyTorch, FastAPI
• Image captioning service serving 1M+ requests per month with sub-200ms latency.
Education
B.Tech in Computer Science 2017 - 2021
Anna University, Chennai`
