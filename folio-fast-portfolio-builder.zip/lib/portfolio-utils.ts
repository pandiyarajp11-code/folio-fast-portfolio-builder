import type { Contact, PortfolioData } from './types'

export function toHref(value: string) {
  if (!value) return ''
  return /^https?:\/\//i.test(value) ? value : `https://${value}`
}

export type ContactLink = { key: keyof Contact; label: string; value: string; href: string }

export function getContactLinks(contact: Contact): ContactLink[] {
  const links: ContactLink[] = []
  if (contact.email) links.push({ key: 'email', label: 'Email', value: contact.email, href: `mailto:${contact.email}` })
  if (contact.phone) links.push({ key: 'phone', label: 'Phone', value: contact.phone, href: `tel:${contact.phone.replace(/[^\d+]/g, '')}` })
  if (contact.github) links.push({ key: 'github', label: 'GitHub', value: contact.github.replace(/^https?:\/\/(www\.)?/, ''), href: toHref(contact.github) })
  if (contact.linkedin) links.push({ key: 'linkedin', label: 'LinkedIn', value: contact.linkedin.replace(/^https?:\/\/(www\.)?/, ''), href: toHref(contact.linkedin) })
  if (contact.website) links.push({ key: 'website', label: 'Website', value: contact.website.replace(/^https?:\/\/(www\.)?/, ''), href: toHref(contact.website) })
  return links
}

export function initials(name: string) {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase())
      .join('') || 'FF'
  )
}

const EMPTY_CONTACT: Contact = { email: '', phone: '', location: '', website: '', linkedin: '', github: '' }

/** Coerces arbitrary edited JSON into a safe PortfolioData shape so themes never crash. */
export function normalizePortfolio(input: unknown): PortfolioData {
  const obj = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>
  const str = (v: unknown) => (typeof v === 'string' ? v : v == null ? '' : String(v))
  const arr = (v: unknown) => (Array.isArray(v) ? v : [])
  const rec = (v: unknown) => (v && typeof v === 'object' ? (v as Record<string, unknown>) : {})
  const contact = rec(obj.contact)

  return {
    username: str(obj.username)
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, ''),
    name: str(obj.name),
    title: str(obj.title),
    bio: str(obj.bio),
    skills: arr(obj.skills).map(str).filter(Boolean),
    projects: arr(obj.projects).map((p) => {
      const r = rec(p)
      return { name: str(r.name), description: str(r.description), tech: arr(r.tech).map(str).filter(Boolean), link: str(r.link) }
    }),
    experience: arr(obj.experience).map((e) => {
      const r = rec(e)
      return { role: str(r.role), company: str(r.company), period: str(r.period), description: str(r.description) }
    }),
    education: arr(obj.education).map((e) => {
      const r = rec(e)
      return { degree: str(r.degree), school: str(r.school), period: str(r.period) }
    }),
    contact: Object.fromEntries(Object.keys(EMPTY_CONTACT).map((k) => [k, str(contact[k])])) as Contact,
    theme: obj.theme === 'minimal' ? 'minimal' : 'aurora',
  }
}
