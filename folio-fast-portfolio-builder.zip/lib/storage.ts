'use client'

import { useSyncExternalStore } from 'react'
import type { PortfolioData, StoredPortfolio } from './types'

const PORTFOLIOS_KEY = 'foliofast:portfolios'
const DRAFT_KEY = 'foliofast:draft'
const CHANGE_EVENT = 'foliofast:change'

function readRaw(key: string) {
  if (typeof window === 'undefined') return null
  try {
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

function writeRaw(key: string, value: string | null) {
  try {
    if (value === null) window.localStorage.removeItem(key)
    else window.localStorage.setItem(key, value)
  } catch {
    // Storage can be unavailable (private mode / quota); fail silently.
  }
  window.dispatchEvent(new Event(CHANGE_EVENT))
}

function subscribe(callback: () => void) {
  window.addEventListener('storage', callback)
  window.addEventListener(CHANGE_EVENT, callback)
  return () => {
    window.removeEventListener('storage', callback)
    window.removeEventListener(CHANGE_EVENT, callback)
  }
}

const parseCache = new Map<string, { raw: string | null; value: unknown }>()

function cachedParse<T>(key: string, fallback: T): T {
  const raw = readRaw(key)
  const cached = parseCache.get(key)
  if (cached && cached.raw === raw) return cached.value as T
  let value: T = fallback
  if (raw) {
    try {
      value = JSON.parse(raw) as T
    } catch {
      value = fallback
    }
  }
  parseCache.set(key, { raw, value })
  return value
}

const EMPTY: Record<string, StoredPortfolio> = {}

export function getPortfolios(): Record<string, StoredPortfolio> {
  return cachedParse(PORTFOLIOS_KEY, EMPTY)
}

export function getDraft(): PortfolioData | null {
  return cachedParse<PortfolioData | null>(DRAFT_KEY, null)
}

export function saveDraft(data: PortfolioData) {
  writeRaw(DRAFT_KEY, JSON.stringify(data))
}

export function publishPortfolio(data: PortfolioData, previousUsername?: string) {
  const all = { ...getPortfolios() }
  const existing = all[previousUsername ?? data.username] ?? all[data.username]
  if (previousUsername && previousUsername !== data.username) delete all[previousUsername]
  const now = Date.now()
  all[data.username] = { ...data, createdAt: existing?.createdAt ?? now, updatedAt: now }
  writeRaw(PORTFOLIOS_KEY, JSON.stringify(all))
  saveDraft(data)
}

export function deletePortfolio(username: string) {
  const all = { ...getPortfolios() }
  delete all[username]
  writeRaw(PORTFOLIOS_KEY, JSON.stringify(all))
}

export function usePortfolios() {
  return useSyncExternalStore(subscribe, getPortfolios, () => null)
}

export function usePortfolio(username: string) {
  const all = usePortfolios()
  if (all === null) return undefined
  return all[username] ?? null
}

export function useDraft() {
  return useSyncExternalStore(subscribe, getDraft, () => undefined)
}
