export type ThemeId = 'minimal' | 'aurora'

export type Experience = {
  role: string
  company: string
  period: string
  description: string
}

export type Project = {
  name: string
  description: string
  tech: string[]
  link: string
}

export type Education = {
  degree: string
  school: string
  period: string
}

export type Contact = {
  email: string
  phone: string
  location: string
  website: string
  linkedin: string
  github: string
}

export type PortfolioData = {
  username: string
  name: string
  title: string
  bio: string
  skills: string[]
  projects: Project[]
  experience: Experience[]
  education: Education[]
  contact: Contact
  theme: ThemeId
}

export type StoredPortfolio = PortfolioData & {
  createdAt: number
  updatedAt: number
}
